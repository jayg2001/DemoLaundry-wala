<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laundry Wallah</title>
       
</head>
<body>
        
    <h1><strong><center>Welcome to Laundry Wallah</center></strong></h1>
     <img src="Laundry.jpg" alt="Logo" height="200">
       <p>
        <strong>Laundry Wallah</strong>  is a trusted and professional laundry service dedicated to making clothes clean, 
        fresh, and well-maintained. <br> We provide high-quality <i>washing, dry cleaning, ironing, and doorstep pickup</i>  and delivery for your convenience.
        Our experienced team uses modern equipment and premium detergents to ensure the best care for every fabric.
        <br>
        We focus on delivering fast, reliable, and affordable services to our customers. <br>
        Customer <i>satisfaction, hygiene</i>, and timely delivery are our top priorities.
        <br>
        Whether it is your daily wear, office clothes, or delicate garments, we handle each item with care. <br>
        At <strong> Laundry Wallah</strong> , we believe that clean clothes create confidence and comfort. <br>
        Choose <strong>Laundry Wallah</strong>  for a hassle-free laundry experience and let us take care of your laundry needs.
       </p>
       <img src="2.jpg" alt="" height="250" width="200">
       <hr>
       <h2> Our Services</h2>
       <ul>  
        <li>Washing</li>
        <li>Drying</li>
        <li>Ironing</li>
        <li>Folding</li>
        <li>Dry</li>
        <li>Cleaning</li>
        <li>Stain Removal</li>
        <li>Express Services</li>
       </ul>
       <hr>

       <h2>Price List</h2>
       <table  border="">
        
        <thead>
        <tr>
            <th>We Offer</th>  
            <th>Price</th>
        </tr>
        </thead>

        <tbody>
        <tr>
            <td>Washing</td>
            <td>200</td>
        </tr>

        <tr>
            <td>Drying</td>
            <td>150</td>
        </tr>

        <tr>
            <td>Ironing</td>
            <td>100</td>
        </tr>

        <tr>
            <td>Dry</td>
            <td>50</td>
        </tr>

        <tr>
            <td>Cleaning</td>
            <td>50</td>
        </tr>

        <tr>
            <td>Stain Removal</td>
            <td>80</td>
        </tr>
        
        <tr>
            <td>Express Services</td>
            <td>650</td>
        </tr>
        </tbody>

       </table>

       <hr>

       <h2>Book Your Appointment</h2>
       <form action="">
        <label for="name"> Name</label>
        <input type="text">
        <label for="Last name"> Last name</label>
        <input type="text">
        <br>
        <label for="Age">Age</label>
        <input type="number">
        <label for="Phone number">Phone Number</label>
        <input type="Number">
        <br>
        <label for="Address">Address</label>
        <input type="text">
        <br> <br>
        <button onclick="showMessage()">Book Laundry Service</button>
<script>
function showMessage() {
    alert("✅ Thank you for choosing Laundry Wallah! Your booking request has been received. We will contact you shortly.");
}
</script>
       </form>
       
       <hr>

       <footer>
        <p> <strong> Laundry Walla</strong></p>
        <p> Contact Us :- 8977654390</p>
        <p> Email:- info@gmail.com</p>
        

       </footer>
       
</body>
</html>